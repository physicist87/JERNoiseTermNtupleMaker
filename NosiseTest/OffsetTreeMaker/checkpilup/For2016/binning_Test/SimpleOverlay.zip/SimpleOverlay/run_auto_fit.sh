#!/bin/tcsh

#################
###Input files###
#################
set inputlists = ("TopptReweightVsNon" "TopptReweightVsNon_others")
#set inputlists = ("TopptReweightVsNon" )
set channels = ("MuMu" "MuEl" "ElEl")
#set channels = ("MuMu" )
foreach i ( $inputlists )
    mkdir -p Output
    mkdir -p Output/${i} 
    set inputDir = ${i}
    foreach j ($channels)
        mkdir -p Output/${i}/${j}
        ./Simple_Overlay $inputDir/${i}_${j}.list Output/${i}/${j} MyConf.cfg 
    end
end
